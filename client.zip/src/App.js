import React, { useEffect, useRef, useState } from "react";
import io from "socket.io-client";

// Change this URL to your deployed server (e.g., https://voconnct-server.herokuapp.com)
const SIGNALING_SERVER = process.env.REACT_APP_SIGNALING_URL || "http://localhost:4000";
const ICE_SERVERS = [{ urls: "stun:stun.l.google.com:19302" }];

function App() {
  const socketRef = useRef();
  const pcRef = useRef();
  const localStreamRef = useRef();
  const remoteStreamRef = useRef();
  const [roomId, setRoomId] = useState("testroom");
  const [joined, setJoined] = useState(false);
  const [status, setStatus] = useState("idle");

  useEffect(() => {
    socketRef.current = io(SIGNALING_SERVER);
    socketRef.current.on("connect", () => console.log("connected", socketRef.current.id));

    socketRef.current.on("signal", async ({ from, data }) => {
      if (!pcRef.current) await createPeerConnection();
      if (data.type === "offer") {
        await pcRef.current.setRemoteDescription(data);
        const answer = await pcRef.current.createAnswer();
        await pcRef.current.setLocalDescription(answer);
        socketRef.current.emit("signal", { room: roomId, to: from, data: pcRef.current.localDescription });
      } else if (data.type === "answer") {
        await pcRef.current.setRemoteDescription(data);
      } else if (data.candidate) {
        try {
          await pcRef.current.addIceCandidate(data);
        } catch (e) {
          console.warn("Add ICE candidate error", e);
        }
      }
    });

    return () => socketRef.current.disconnect();
  }, [roomId]);

  async function createPeerConnection() {
    pcRef.current = new RTCPeerConnection({ iceServers: ICE_SERVERS });
    localStreamRef.current.getTracks().forEach((track) => pcRef.current.addTrack(track, localStreamRef.current));

    remoteStreamRef.current = new MediaStream();
    pcRef.current.ontrack = (event) => {
      event.streams[0].getTracks().forEach((t) => remoteStreamRef.current.addTrack(t));
      const remoteEl = document.getElementById("remoteAudio");
      if (remoteEl) {
        remoteEl.srcObject = remoteStreamRef.current;
      }
    };

    pcRef.current.onicecandidate = (event) => {
      if (event.candidate) {
        socketRef.current.emit("signal", { room: roomId, data: { candidate: event.candidate } });
      }
    };
  }

  async function joinRoom() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      localStreamRef.current = stream;
      const localEl = document.getElementById("localAudio");
      if (localEl) localEl.srcObject = stream;

      socketRef.current.emit("join", roomId);
      setJoined(true);
      setStatus("joined");

      await createPeerConnection();
      const offer = await pcRef.current.createOffer();
      await pcRef.current.setLocalDescription(offer);
      socketRef.current.emit("signal", { room: roomId, data: pcRef.current.localDescription });
      setStatus("calling");
    } catch (e) {
      console.error("getUserMedia error", e);
    }
  }

  function leaveRoom() {
    if (pcRef.current) pcRef.current.close();
    socketRef.current.emit("leave", roomId);
    setJoined(false);
    setStatus("left");
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>VoConnect — WebRTC Test</h2>
      <div>
        <label>Room ID: </label>
        <input value={roomId} onChange={(e) => setRoomId(e.target.value)} />
      </div>
      <div style={{ marginTop: 10 }}>
        {!joined ? (
          <button onClick={joinRoom}>Join & Call</button>
        ) : (
          <button onClick={leaveRoom}>Leave</button>
        )}
      </div>
      <div style={{ marginTop: 20 }}>
        <div>Status: {status}</div>
        <audio id="localAudio" autoPlay muted />
        <audio id="remoteAudio" autoPlay />
      </div>
      <p>Open this page in two different browsers/windows and join the same room to test audio calls.</p>
    </div>
  );
}

export default App;
